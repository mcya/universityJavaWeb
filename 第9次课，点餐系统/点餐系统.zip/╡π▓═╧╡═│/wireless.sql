﻿/*
Navicat MySQL Data Transfer

Source Server         : 192.168.124.12_3306
Source Server Version : 50527
Source Host           : 192.168.124.12:3306
Source Database       : wireless

Target Server Type    : MYSQL
Target Server Version : 50527
File Encoding         : 65001

Date: 2014-12-12 09:42:22
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `board`
-- ----------------------------
DROP TABLE IF EXISTS `board`;
CREATE TABLE `board` (
  `boardId` int(4) NOT NULL AUTO_INCREMENT,
  `boardName` varchar(10) NOT NULL,
  `isBook` boolean,
  `bookTime` datetime default null,
  PRIMARY KEY (`boardId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of board
-- ----------------------------
INSERT INTO `board` VALUES ('1', '纽约', '0', '2014-12-12 09:39:56');
INSERT INTO `board` VALUES ('2', '纽约', '0', '2014-12-12 09:40:50');
INSERT INTO `board` VALUES ('3', '靖西2', '1', '2014-12-12 09:25:10');
INSERT INTO `board` VALUES ('4', '靖西3', '1', '2014-12-12 09:19:51');
INSERT INTO `board` VALUES ('5', '靖西4', '1', '2014-12-11 23:47:49');
INSERT INTO `board` VALUES ('6', '靖西5', '1', '2014-12-12 09:15:49');
INSERT INTO `board` VALUES ('7', '北京', '1', '2014-12-12 09:25:20');
INSERT INTO `board` VALUES ('8', '规划', '1', '2014-12-12 09:37:17');

-- ----------------------------
-- Table structure for `dishes`
-- ----------------------------
DROP TABLE IF EXISTS `dishes`;
CREATE TABLE `dishes` (
  `dishesId` int(11) NOT NULL,
  `dishesName` varchar(8) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `dishesPrice` float ,
  `vipPrice` float,
  `summary` varchar(200) DEFAULT NULL,
  `picture` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`dishesId`),
  KEY `type_id_dishes_type` (`typeId`),
  CONSTRAINT `type_id_dishes_type` FOREIGN KEY (`typeId`) REFERENCES `dishtype` (`typeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dishes
-- ----------------------------

-- ----------------------------
-- Table structure for `dishtype`
-- ----------------------------
DROP TABLE IF EXISTS `dishtype`;
CREATE TABLE `dishtype` (
  `typeId` int(11) NOT NULL,
  `typeName` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`typeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dishtype
-- ----------------------------

-- ----------------------------
-- Table structure for `oderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `oderdetail`;
CREATE TABLE `oderdetail` (
  `de_id` int(11) NOT NULL,
  `dishesId` int(11) NOT NULL,
  `o_id` int(11) NOT NULL,
  `de_disesPrice` float,
  `number` int(11),
  PRIMARY KEY (`de_id`),
  KEY `deshesid` (`dishesId`),
  KEY `o_id` (`o_id`),
  CONSTRAINT `deshesid` FOREIGN KEY (`dishesId`) REFERENCES `dishes` (`dishesId`),
  CONSTRAINT `o_id` FOREIGN KEY (`o_id`) REFERENCES `order` (`o_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of oderdetail
-- ----------------------------

-- ----------------------------
-- Table structure for `order`
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `o_id` int(11) NOT NULL,
  `boardId` int(11) NOT NULL,
  `o_date` datetime DEFAULT NULL,
  `o_total` float,
  `o_isCount` tinyint(1),
  PRIMARY KEY (`o_id`),
  KEY `board_id_order_boardid` (`boardId`),
  CONSTRAINT `board_id_order_boardid` FOREIGN KEY (`boardId`) REFERENCES `board` (`boardId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
