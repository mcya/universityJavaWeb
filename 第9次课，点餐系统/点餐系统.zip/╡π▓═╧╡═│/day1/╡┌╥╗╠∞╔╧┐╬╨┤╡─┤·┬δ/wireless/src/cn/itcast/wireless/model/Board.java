package cn.itcast.wireless.model;

import java.util.Date;

/**
 * ����ʵ��
 * 
 * @author Leo.Chen
 * 
 */
public class Board {
	// �������
	private int id;
	// ��������
	private String name;
	// Ԥ��״̬
	private boolean isBook;
	// Ԥ��ʱ��
	private Date bookTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean getIsBook() {
		return isBook;
	}

	public void setIsBook(boolean isBook) {
		this.isBook = isBook;
	}

	public Date getBookTime() {
		return bookTime;
	}

	public void setBookTime(Date bookTime) {
		this.bookTime = bookTime;
	}

}
