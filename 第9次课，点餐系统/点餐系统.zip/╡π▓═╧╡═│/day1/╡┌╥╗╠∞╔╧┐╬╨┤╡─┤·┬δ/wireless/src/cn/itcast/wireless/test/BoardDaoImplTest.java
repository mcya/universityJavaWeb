package cn.itcast.wireless.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import cn.itcast.wireless.dao.BoardDao;
import cn.itcast.wireless.dao.impl.BoardDaoImpl;
import cn.itcast.wireless.model.Board;

public class BoardDaoImplTest {
	
	private BoardDao boardDao = new BoardDaoImpl();
	@Test
	public void testSave() {
		for (int i = 0; i < 6; i++) {
			Board board = new Board();
			board.setName("��ɫ"+i);
			board.setIsBook(true);
			board.setBookTime(new Date());
			// �������
			boardDao.save(board);
		}
	}
	

	@Test
	public void testDelete() {
		boardDao.delete(1);
	}

	@Test
	public void testUpdate() {
		Board board = new Board();
		board.setId(1);
		board.setName("ŦԼ");
		board.setIsBook(false);
		board.setBookTime(new Date());
		// ���²���
		boardDao.update(board);
	}
	
	
	@Test
	public void testQueryAll() {
		List<Board> list = boardDao.queryAll();
		System.out.println(list.size());
	}
	
	
	@Test
	public void testQueryById() {
		Board board = boardDao.queryById(2);
		System.out.println(board.getName());
	}
	
	
	

}
