package cn.itcast.wireless.service.impl;

import java.util.List;

import cn.itcast.wireless.dao.BoardDao;
import cn.itcast.wireless.dao.impl.BoardDaoImpl;
import cn.itcast.wireless.model.Board;
import cn.itcast.wireless.service.BoardService;
/**
 * ����Serviceʵ����
 * @author Leo.Chen
 *
 */
public class BoardServiceImpl implements BoardService {
	private BoardDao boardDao = new BoardDaoImpl(); 

	@Override
	public void save(Board board) {
		boardDao.save(board);
	}

	@Override
	public void delete(int id) {
		boardDao.delete(id);
	}

	@Override
	public void update(Board board) {

	}

	@Override
	public List<Board> queryAll() {
		// ������������
		return boardDao.queryAll();
	}

	@Override
	public Board queryById(int id) {
		return null;
	}

}
