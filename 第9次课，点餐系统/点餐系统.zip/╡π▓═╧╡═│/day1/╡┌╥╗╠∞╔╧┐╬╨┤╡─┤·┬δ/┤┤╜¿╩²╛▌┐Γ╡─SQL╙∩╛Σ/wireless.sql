CREATE DATABASE wireless;
USE wireless;
CREATE TABLE board(
     id INT PRIMARY KEY AUTO_INCREMENT,
     NAME VARCHAR(30) NOT NULL,
     isBook BOOLEAN,
     bookTime DATETIME
);
SELECT * FROM board;